"""What a model still needs on this computer, in plain words: the one place the Folder step, the download question and the final summary ask.

A model that is already installed is "already downloaded". What can still be missing are helper files, each with its own size: the
draft layer (MTP, makes answers faster) and the picture reader. Only when the weights themselves are gone does it say the model
is downloaded again. Nothing here reads more than a run config and file existence.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from strata_control import discovery
from strata_control.discovery import MMPROJ_GB, MTP_FETCH_GB


@dataclass
class Part:
    kind: str                        # weights | mtp | mmproj
    label: str                       # "the draft layer"
    gb: float


@dataclass
class ModelState:
    installed: bool = False          # a run config for this model exists and names files that are there
    own_files: bool = False          # the person's own model files
    total_gb: float = 0.0            # the whole model (the catalog's figure)
    parts: list[Part] = field(default_factory=list)       # what is missing and would be downloaded
    folder: Path | None = None       # where the model lives now (its data folder), None when not installed
    on_disk_gb: float = 0.0          # weights already in the model's folder (a partial download)
    notes: list[str] = field(default_factory=list)

    @property
    def remaining_gb(self) -> float:
        return sum(p.gb for p in self.parts)

    @property
    def only_helpers(self) -> bool:
        return bool(self.parts) and all(p.kind != "weights" for p in self.parts)

    def _names(self) -> str:
        names = [f"{p.label} ({p.gb:.1f} GB)" for p in self.parts]
        return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]

    def headline(self) -> str:
        """One plain sentence for the size line of the Folder step."""
        if self.own_files:
            if not self.parts:
                return "Your model files are used where they are. The model itself needs no download."
            return f"Your model files are used where they are. Strata still needs to fetch {self._names()}."
        if self.installed and not self.parts:
            return f"Already downloaded ({self.total_gb:.0f} GB on this computer). The model needs nothing more."
        if self.installed and self.only_helpers:
            first = self.parts[0]
            if len(self.parts) == 1:
                return f"The model is already downloaded ({self.total_gb:.0f} GB). Only {first.label} is missing ({first.gb:.1f} GB)."
            return f"The model is already downloaded ({self.total_gb:.0f} GB). Only {self._names()} are missing."
        if self.installed:
            return (f"The model's files are no longer all on this computer. About {self.remaining_gb:.0f} GB would be downloaded "
                    f"({self._names()}).")
        if self.on_disk_gb >= 1:
            return (f"{self.on_disk_gb:.0f} GB of the model is already in the folder. About {self.remaining_gb:.0f} GB left to download "
                    f"(the whole model is {self.total_gb:.0f} GB).")
        return f"Not downloaded yet: about {self.remaining_gb:.0f} GB to download."

    def question(self) -> tuple[str, str]:
        """(title, text) for the "Download?" pop-up before a start that needs a download."""
        gb = self.remaining_gb
        if self.only_helpers:
            return (f"Download {self._names()}?",
                    "The model itself is already on this computer and is not downloaded again. Strata needs this extra file to start "
                    "with the choices you made; an interrupted download continues where it stopped.")
        return (f"Download about {gb:.0f} GB?",
                f"This model is not on this computer yet. Strata will download about {gb:.0f} GB now; "
                "an interrupted download continues where it stopped.")


#: The families whose setup also fetches the draft layer and the picture reader after the model (setup.py steps 5 and 6). NVFP4 packs bring
#: theirs inside the download, Qwen3.6 has its own engine path.
HELPER_FAMILIES = ("qwen", "swift", "coder", "unsloth", "gyro")


def resolved_drafting(drafting: str | None, family: str | None, *, model_name: str | None = None, args: list | None = None,
                      vram_mib: float | None = None, engine_backend: str | None = None) -> str:
    """The drafter a choice means for this family on this computer: ``dflash2`` | ``mtp`` | ``off`` (strata_control/drafting.py: Auto is DFlash2 where the engine
    has it). ``model_name`` / ``args`` / ``vram_mib``: the model's set and the card signals the start's decision reads (runner.auto_signals; the 12 GB card with
    IQ3_S is the MTP). Never raises; an unknown computer is the MTP."""
    try:
        from strata_control import drafting as _d
        backend, archs = _d.hardware_for(engine_backend)   # #5109: the config's card family (runner.auto_signals), else detect_hardware()
        return _d.choice_of(drafting, family=family, backend=backend, archs=archs, model_name=model_name, args=args, vram_mib=vram_mib)
    except Exception:                                        # noqa: BLE001
        return "mtp"


def drafting_for_family(choice: str | None, family: str | None) -> str | None:
    """The Drafting choice to keep when the model changes to `family`: DFlash2/MTP/Off belong to Qwen3.8-Flash-Next (qwen, gyro, unsloth);
    native .strata models (Inkling-2-Mini, Hy4-Flash) keep 'off' or 'auto'; any other model (Coder, Swift, NVFP4) goes back to Auto (None)."""
    if family in ("inkling-2-mini", "hy4-flash"):
        return choice if choice in ("auto", "off") else None
    from strata_control import drafting as _d
    return choice if (not family or family in _d.SUPPORTED_FAMILIES) else None


def drafting_to_save(key: str, saved: object) -> str | None:
    """What the Drafting step writes into the launch settings for the row the person chose. Auto stays "nobody chose" (None: a saved preset writes nothing), except when the
    model's own settings file already holds another choice (the app's Models screen writes its Drafting choice there and a launch starts from that file): then Auto is
    written as "auto", so it overrides the older choice instead of silently running it."""
    if key != "auto":
        return key
    from strata_control import drafting as _d
    return "auto" if saved is not None and _d.normalize(saved) != "auto" else None


def layer_off_without_choice(base: dict | None) -> bool:
    """The model's installed config has its draft layer off ("mtp": false: setup's --mtp off from a Drafting Off launch, or the app's Draft layer switch) and holds
    no Drafting choice: the engine starts without a drafter, so the Drafting step shows Off; a drafter picked there is saved (runner.layer_back)."""
    return isinstance(base, dict) and base.get("drafting") is None and base.get("mtp") is False


def mtp_choice(mtp: str | None, drafting: str | None = None) -> str | None:
    """The draft-layer choice for what to fetch: off when the person said --mtp off, or the drafter is off or DFlash2 (``drafting`` is the resolved drafter,
    resolved_drafting(); nothing then uses the layer, so a new install does not download it), else as chosen."""
    if str(drafting or "").strip().lower() in ("off", "dflash2"):
        return "off"
    return mtp


def mmproj_name(catalog, family: str | None) -> str:
    if family == "hy4-flash":
        from strata_control import hy4_family
        return hy4_family.VISION_FILE
    if family == "inkling-2-mini":
        from strata_control import inkling_family
        return inkling_family.VISION_FILE
    try:
        _m, families, _c, _s = catalog.tables()
        name = (families.get(family or "") or {}).get("mmproj")
        if name:
            return str(name)
        mod = catalog.strata.setup_module()
        if mod is not None and getattr(mod, "MMPROJ", None):
            return str(mod.MMPROJ)
    except Exception:                                        # noqa: BLE001
        pass
    return "mmproj-Qwen3.8-Flash-Next-BF16.gguf"


def assess(catalog, family: str | None, model: str | None, *, vision: str = "off", model_path: str | None = None,
           data_dir: str | Path | None = None, config: Path | None = None, desc: dict | None = None, rows: list | None = None,
           mtp: str | None = None, drafting: str | None = None, use_installed: bool = True) -> ModelState:
    """The state of `family model` for these choices. `config` / `desc` are the installed run config and its description (looked up when
    not given)."""
    st = ModelState()
    mtp = mtp_choice(mtp, drafting)
    row = next((r for r in (rows if rows is not None else catalog.rows()) if r.family == family and r.model == model), None) if (family and model) else None
    st.total_gb = float(row.download_gb) if row else 0.0
    wants_pictures = vision not in ("off", "no") and (row is None or row.images)
    data = Path(data_dir) if data_dir else None
    if model_path:
        st.own_files = True
        if family in ("hy4-flash", "inkling-2-mini"):
            from strata_control import hy4_family, inkling_family
            fam_mod = inkling_family if family == "inkling-2-mini" else hy4_family
            p = Path(model_path)
            own_dir = p if p.is_dir() else p.parent
            if wants_pictures and not reader_present(catalog, family, [data, *data_places(catalog, data)], own=own_dir):
                st.parts.append(Part("mmproj", "the picture reader", round(fam_mod.FILES[fam_mod.VISION_FILE][0] / 1e9, 2)))
            return st
        first = _first_gguf(Path(model_path))
        beside = discovery.prepared_beside(first, data_places(catalog, data)) if first else {}     # the model folder's own layout, then --data-dir and the remembered folder (where setup writes the draft layer)
        st.folder = beside.get("data_dir")
        if beside.get("pack") is not None and beside.get("mtp") is None and mtp != "off":
            st.parts.append(Part("mtp", "the draft layer", MTP_FETCH_GB))
        if wants_pictures and beside.get("pack") is not None and \
                not reader_present(catalog, family, [st.folder, *data_places(catalog, data)], own=first.parent if first else None):
            st.parts.append(Part("mmproj", "the picture reader", MMPROJ_GB))
        return st
    if config is None and family and model and use_installed:          # (False: the installed copy is in another data folder than the one this launch uses)
        config = catalog.installed_config(catalog.tag_of(family, model))
    cfg = None
    if config is not None:
        try:
            import json
            cfg = json.loads(Path(config).read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            cfg = None
    if cfg is not None:
        fp = discovery.footprint(cfg, Path(config))
        st.installed = True
        st.folder = fp.data_dir
        gone = [m for m in fp.missing() if m.kind == "weights"]
        if gone:
            st.installed = False
            st.parts.append(Part("weights", "the model", max(st.total_gb, 0.0)))
            return st
        v_gb = MMPROJ_GB
        if family == "hy4-flash":
            from strata_control import hy4_family
            v_gb = round(hy4_family.FILES[hy4_family.VISION_FILE][0] / 1e9, 2)
        elif family == "inkling-2-mini":
            from strata_control import inkling_family
            v_gb = round(inkling_family.FILES[inkling_family.VISION_FILE][0] / 1e9, 2)
        for m in fp.missing():
            if m.kind == "mtp" and mtp != "off":
                st.parts.append(Part("mtp", "the draft layer", MTP_FETCH_GB))
            elif m.kind == "mmproj" and wants_pictures:
                st.parts.append(Part("mmproj", "the picture reader", v_gb))
        images = (desc or {}).get("images") if desc is not None else ("cpu" if fp.mmproj else "off")
        if wants_pictures and (images in (None, "off")) and not any(p.kind == "mmproj" for p in st.parts):
            if family in ("hy4-flash", "inkling-2-mini"):
                own_dir = fp.weights[0].parent if fp.weights else None
                if not reader_present(catalog, family, [st.folder, *data_places(catalog, data)], own=own_dir):
                    st.parts.append(Part("mmproj", "the picture reader", v_gb))
            else:
                base = st.folder / "models" if st.folder else data
                have = (base / mmproj_name(catalog, family)) if base else None
                if have is None or not have.exists():
                    st.parts.append(Part("mmproj", "the picture reader", MMPROJ_GB))
        return st
    # not installed: whatever of the weights is in the model's folder counts
    if family and model:
        base = data or Path(catalog.data_dir())
        folder = catalog.model_folder(base, family, model)
        if family in ("hy4-flash", "inkling-2-mini"):
            from strata_control import hy4_family, inkling_family
            fam_mod = inkling_family if family == "inkling-2-mini" else hy4_family
            weight_names = fam_mod.files_of(model, False)
            got_weights = 0
            missing_weights = 0
            for n in weight_names:
                expected = fam_mod.FILES[n][0]
                p = folder / n
                part = folder / (n + ".part")
                try:
                    if p.is_file() and p.stat().st_size == expected and not part.exists():
                        got_weights += expected
                    elif part.is_file():
                        got_weights += min(part.stat().st_size, expected)
                        missing_weights += max(0, expected - part.stat().st_size)
                    else:
                        missing_weights += expected
                except OSError:
                    missing_weights += expected
            v_size = fam_mod.FILES[fam_mod.VISION_FILE][0]
            v_have = False
            if wants_pictures:
                vp = folder / fam_mod.VISION_FILE
                vpart = folder / (fam_mod.VISION_FILE + ".part")
                try:
                    if vp.is_file() and vp.stat().st_size == v_size and not vpart.exists():
                        v_have = True
                        got_weights += v_size
                except OSError:
                    pass
            st.on_disk_gb = got_weights / 1e9
            if missing_weights > 0:
                rem = missing_weights + (0 if (not wants_pictures or v_have) else v_size)
                st.parts.append(Part("weights", "the model", rem / 1e9))
            elif wants_pictures and not v_have:
                st.parts.append(Part("mmproj", "the picture reader", round(v_size / 1e9, 2)))
            return st
        got = 0
        try:
            got = sum(f.stat().st_size for f in folder.glob("*.gguf") if not f.name.lower().startswith("mmproj"))
        except OSError:
            pass
        st.on_disk_gb = got / 1e9
        st.parts.append(Part("weights", "the model", max(st.total_gb - st.on_disk_gb, 0.0)))
        if family in HELPER_FAMILIES:
            # setup fetches the draft layer and the picture reader after the model, so the question and the disk check count them too
            if mtp != "off" and not _is_file(base / "mtp" / "rt" / "experts.bin"):
                st.parts.append(Part("mtp", "the draft layer", MTP_FETCH_GB))
            if wants_pictures and not reader_present(catalog, family, [base, *data_places(catalog, None)]):     # setup's rule: the pinned name, here or in a folder it reuses
                st.parts.append(Part("mmproj", "the picture reader", MMPROJ_GB))
    return st


def _is_file(path: Path) -> bool:
    """Path.is_file() that says no, not PermissionError, for a file below a folder this account may not read (0.2.17: it stopped the Save screen's repaint)."""
    try:
        return path.is_file()
    except OSError:
        return False


def data_places(catalog, data: Path | None) -> list[Path]:
    """The data folders besides the model folder's own layout that may already hold the draft layer: the one the launch names (--data-dir), then the one every command agrees on."""
    out: list[Path] = [data] if data else []
    try:
        default = catalog.data_dir()
        if default and not any(os.path.normcase(str(default)) == os.path.normcase(str(d)) for d in out):
            out.append(Path(default))
    except Exception:                                        # noqa: BLE001 - a question asked early is never a reason to stop
        pass
    return out


def mmproj_size(catalog, family: str | None, name: str) -> int | None:
    """The pinned size of the family's picture reader (setup's fam["mmproj_sha256"] or ISTA_FILES), None when setup does not pin one."""
    try:
        _m, families, _c, _s = catalog.tables()
        pin = (families.get(family or "") or {}).get("mmproj_sha256")
        if not pin:
            mod = catalog.strata.setup_module()
            pin = (getattr(mod, "ISTA_FILES", None) or {}).get(name) if mod is not None else None
        return int(pin[0]) if pin else None
    except Exception:                                        # noqa: BLE001
        return None


def reader_present(catalog, family: str | None, data_folders, own: Path | None = None) -> bool:
    """Whether setup will find the picture reader without a download - setup's own rule (setup.py step 5 and mmproj_beside), not any
    mmproj*.gguf: the family's pinned file name in a data folder's models/ (the one in use, or a folder setup reuses), or with the person's own
    files in their folder (by name), or in the folder above it or that folder's models/ (by name, at the pinned size). Or, when there is no pinned
    file, a verified Unsloth mmproj-F16.gguf (setup.accepted_alt_reader: the same function the start uses)."""
    if family == "hy4-flash":
        from strata_control import hy4_family
        size = hy4_family.FILES[hy4_family.VISION_FILE][0]
        places = [Path(b) / sub / "hy4-flash" / hy4_family.VISION_FILE for b in data_folders if b for sub in ("models", "Models")]
        if own is not None:
            places.insert(0, Path(own) / hy4_family.VISION_FILE)
        for f in places:
            try:
                if f.is_file() and f.stat().st_size == size and not f.with_name(f.name + ".part").exists():
                    return True
            except OSError:
                pass
        return False
    name = mmproj_name(catalog, family)
    for base in data_folders:
        if not base:
            continue
        for sub in ("models", "Models"):
            try:
                if (Path(base) / sub / name).is_file():
                    return True
            except OSError:
                pass
    if own is not None:
        own = Path(own)
        try:
            if (own / name).is_file():
                return True
            size = mmproj_size(catalog, family, name)
            for r in (own.parent, own.parent / "models"):
                f = r / name
                if f.is_file() and (size is None or f.stat().st_size == size):
                    return True
        except OSError:
            pass
        try:                                                 # the same file under another name in their folder (0.2.17: setup.own_reader_by_content, by size and SHA-256)
            mod = catalog.strata.setup_module()
            _m, families, _c, _s = catalog.tables()
            pin = (families.get(family or "") or {}).get("mmproj_sha256") or (getattr(mod, "ISTA_FILES", None) or {}).get(name)
            if mod is not None and pin and mod.own_reader_by_content(own, name, pin[0], pin[1], start=False) is not None:
                return True
        except Exception:                                    # noqa: BLE001 - the plan must not fail on this
            pass
    try:                                                     # no pinned file: a verified Unsloth mmproj-F16.gguf the person already has counts, as in setup
        mod = catalog.strata.setup_module()
        alt = (getattr(mod, "ALT_READERS", None) or {}).get(name) if mod is not None else None
        if alt is None:
            return False
        places = [Path(b) / sub / alt[0] for b in data_folders if b for sub in ("models", "Models")]
        if own is not None:
            places += [Path(own) / alt[0], Path(own).parent / alt[0], Path(own).parent / "models" / alt[0]]
        return mod.accepted_alt_reader(name, places, start=False) is not None      # (the plan hashes without writing a mark and says nothing)
    except Exception:                                        # noqa: BLE001 - the plan must not fail on this
        return False


def _first_gguf(path: Path) -> Path | None:
    try:
        if path.is_file():
            return path
        found = sorted(p for p in path.glob("*.gguf") if not p.name.lower().startswith("mmproj"))
        return found[0] if found else None
    except OSError:
        return None
